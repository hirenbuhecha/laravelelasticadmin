<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="msapplication-TileColor" content="#FFFFFF">
<meta name="msapplication-TileImage" content="/img/icons/favicon-144.png">
<meta name="msapplication-config" content="/img/icons/browserconfig.xml">
<meta content="yes" name="apple-mobile-web-app-capable"/>
<meta name="apple-mobile-web-app-status-bar-style" content="black"/>
<meta name="apple-mobile-web-app-title" content="DATA MANAGER | Powered by Ericsson">
<meta name="application-name" content="DATA MANAGER | Powered by Ericsson">
<link rel="shortcut icon" href="/img/icons/favicon.ico">
<link rel="icon" sizes="16x16 32x32 64x64" href="/img/icons/favicon.ico">
<link rel="icon" type="image/png" sizes="196x196" href="/img/icons/favicon-192.png">
<link rel="icon" type="image/png" sizes="160x160" href="/img/icons/favicon-160.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/icons/favicon-96.png">
<link rel="icon" type="image/png" sizes="64x64" href="/img/icons/favicon-64.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/icons/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/icons/favicon-16.png">
<link rel="apple-touch-icon" href="/img/icons/favicon-57.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/icons/favicon-114.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/icons/favicon-72.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/icons/favicon-144.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/icons/favicon-60.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/icons/favicon-120.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/icons/favicon-76.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/icons/favicon-152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/icons/favicon-180.png">