<!-- navbar -->
<nav class="navbar  navbar-default navbar-fixed-top" role="navigation">
    <div class="container-fluid">

            <a href="#menu-toggle"class="navbar-brand" id="menu-toggle">
                <i class="fa fa-bars" aria-hidden="true" ></i> {{config('app.name','ELSADMIN')}}
            </a>

    </div>
</nav>
<!-- /.navbar -->