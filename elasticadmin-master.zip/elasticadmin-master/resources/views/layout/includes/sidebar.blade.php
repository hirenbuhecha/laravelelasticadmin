<!-- Sidebar -->
<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li class="active">
            <a href="/entity"><i class="fa fa-home"></i> Manage Entity </a>
    </ul>
</div>
<!-- /#sidebar-wrapper -->