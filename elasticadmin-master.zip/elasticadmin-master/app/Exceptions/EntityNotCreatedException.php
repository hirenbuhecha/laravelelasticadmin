<?php

namespace App\Exceptions;

class EntityNotCreatedException extends \Exception {

} 