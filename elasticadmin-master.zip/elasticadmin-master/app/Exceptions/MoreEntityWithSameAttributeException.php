<?php

namespace App\Exceptions;

class MoreEntityWithSameAttributeException extends \Exception {

} 