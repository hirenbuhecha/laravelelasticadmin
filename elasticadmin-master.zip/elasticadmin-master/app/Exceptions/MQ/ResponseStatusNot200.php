<?php

namespace App\Exceptions\MQ;

class ResponseStatusNot200 extends \Exception {
}