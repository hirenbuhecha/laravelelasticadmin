<?php

namespace App\Exceptions;

class EntityNotDeletedException extends \Exception {

} 