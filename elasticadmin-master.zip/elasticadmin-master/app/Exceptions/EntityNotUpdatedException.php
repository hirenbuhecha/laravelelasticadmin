<?php

namespace App\Exceptions;

class EntityNotUpdatedException extends \Exception {

} 