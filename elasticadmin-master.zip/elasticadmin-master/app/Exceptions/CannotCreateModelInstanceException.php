<?php
/**
 * Created by PhpStorm.
 * User: Francesco
 * Date: 19/06/2015
 * Time: 15.58
 */

namespace App\Exceptions;


class CannotCreateModelInstanceException extends \Exception {

} 