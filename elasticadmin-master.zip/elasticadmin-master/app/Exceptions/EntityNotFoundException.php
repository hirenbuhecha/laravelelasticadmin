<?php

namespace App\Exceptions;

class EntityNotFoundException extends \Exception {

} 