<?php

namespace App\Exceptions;

class NoOperationNeededException extends \Exception {

} 